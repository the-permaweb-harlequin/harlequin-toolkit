#!/bin/bash
# Harlequin CLI Template Installation Script for AssemblyScript

set -e

PROJECT_NAME="$1"
if [ -z "$PROJECT_NAME" ]; then
    echo "Usage: $0 <project-name>"
    exit 1
fi

echo "🎭 Creating AssemblyScript AO process: $PROJECT_NAME"

# Replace template variables
find . -type f -name "*.md" -o -name "*.json" -o -name "*.go" -o -name "go.mod" | xargs sed -i.bak "s/{{PROJECT_NAME}}/$PROJECT_NAME/g"
find . -name "*.bak" -delete

echo "✅ Template prepared successfully!"
echo ""
echo "Next steps:"
echo "  pnpm install"
echo "  pnpm run build"
echo "  pnpm run test"
echo ""
echo "Happy coding! 🚀"
