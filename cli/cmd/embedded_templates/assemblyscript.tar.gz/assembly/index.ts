import { JSON } from "assemblyscript-json/assembly";

// AO Message interface
class AOMessage {
  constructor(
    public Target: string = "",
    public Action: string = "",
    public Data: string = "",
    public Anchor: string = "",
    public Tags: Map<string, string> = new Map()
  ) {}
}

// AO Environment interface
class AOEnvironment {
  constructor(
    public Process: AOProcess = new AOProcess(),
    public Module: string = ""
  ) {}
}

class AOProcess {
  constructor(
    public Id: string = "",
    public Owner: string = "",
    public Tags: Map<string, string> = new Map()
  ) {}
}

// AO Response interface
class AOResponse {
  constructor(
    public Output: string = "",
    public Error: string = "",
    public Messages: Array<AOMessage> = [],
    public Spawns: Array<AOMessage> = [],
    public Assignments: Array<AOMessage> = [],
    public GasUsed: i32 = 0
  ) {}
}

// Main handler function - this is the entry point for AO
export function handle(msgPtr: i32, envPtr: i32): i32 {
  // Convert WebAssembly memory pointers to strings
  const msgJson = String.UTF8.decode(changetype<ArrayBuffer>(msgPtr));
  const envJson = String.UTF8.decode(changetype<ArrayBuffer>(envPtr));

  // Parse the JSON inputs
  const msgObj = JSON.parse(msgJson);
  const envObj = JSON.parse(envJson);

  // Extract action from message tags
  let action = "unknown";
  if (msgObj.isObj) {
    const tagsObj = msgObj.getObj("Tags");
    if (tagsObj !== null && tagsObj.isObj) {
      const keys = tagsObj.keys;
      for (let i = 0; i < keys.length; i++) {
        const key = keys[i];
        const value = tagsObj.getValue(key);
        if (key === "Action" && value !== null && value.isString) {
          action = value.getString();
          break;
        }
      }
    }
  }

  // Create response based on action
  const response = new AOResponse();

  if (action === "Hello") {
    response.Output = "Hello, AO World!";
  } else if (action === "Info") {
    response.Output = "This is an AO process built with AssemblyScript";
  } else if (action === "Echo") {
    // Echo back the message data
    if (msgObj.isObj) {
      const dataValue = msgObj.getValue("Data");
      if (dataValue !== null && dataValue.isString) {
        response.Output = "Echo: " + dataValue.getString();
      } else {
        response.Output = "Echo: (no data)";
      }
    }
  } else {
    response.Output = "Unknown action: " + action;
    response.Error = "Supported actions: Hello, Info, Echo";
  }

  // Convert response to JSON
  const responseObj = new JSON.Obj();
  responseObj.set("Output", response.Output);
  responseObj.set("Error", response.Error);
  responseObj.set("Messages", new JSON.Arr());
  responseObj.set("Spawns", new JSON.Arr());
  responseObj.set("Assignments", new JSON.Arr());
  responseObj.set("GasUsed", response.GasUsed);

  const responseJson = responseObj.stringify();

  // Allocate memory for the response and return pointer
  const responseBuffer = String.UTF8.encode(responseJson);
  const responsePtr = heap.alloc(responseBuffer.byteLength);
  memory.copy(responsePtr, changetype<usize>(responseBuffer), responseBuffer.byteLength);

  return responsePtr;
}
