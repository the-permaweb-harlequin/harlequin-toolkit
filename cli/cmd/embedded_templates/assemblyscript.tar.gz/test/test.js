import { readFileSync } from 'fs';
import { createAOSLoader } from '@permaweb/ao-loader';

async function test() {
  console.log('🧪 Testing AO AssemblyScript Process...\n');

  try {
    // Load the compiled WASM
    const wasmBinary = readFileSync('./build/process.wasm');
    const loader = createAOSLoader();

    // Create test message
    const message = {
      Target: 'test-process',
      Action: 'Hello',
      Data: '',
      Anchor: '0',
      Tags: [
        { name: 'Action', value: 'Hello' }
      ]
    };

    const environment = {
      Process: {
        Id: 'test-process-id',
        Owner: 'test-owner',
        Tags: []
      },
      Module: 'test-module'
    };

    console.log('📨 Sending message:', JSON.stringify(message, null, 2));

    // Test the process
    const result = await loader(wasmBinary, message, environment);

    console.log('📋 Response:', JSON.stringify(result, null, 2));

    // Validate response
    if (result.Output === 'Hello, AO World!') {
      console.log('✅ Test passed: Hello action works correctly');
    } else {
      console.log('❌ Test failed: Unexpected output');
      process.exit(1);
    }

    // Test Echo action
    const echoMessage = {
      ...message,
      Action: 'Echo',
      Data: 'Hello from test!',
      Tags: [
        { name: 'Action', value: 'Echo' }
      ]
    };

    console.log('\n📨 Testing Echo action...');
    const echoResult = await loader(wasmBinary, echoMessage, environment);
    console.log('📋 Echo Response:', JSON.stringify(echoResult, null, 2));

    if (echoResult.Output.includes('Hello from test!')) {
      console.log('✅ Test passed: Echo action works correctly');
    } else {
      console.log('❌ Test failed: Echo did not work as expected');
      process.exit(1);
    }

    console.log('\n🎉 All tests passed!');

  } catch (error) {
    console.error('❌ Test failed with error:', error);
    process.exit(1);
  }
}

test();
